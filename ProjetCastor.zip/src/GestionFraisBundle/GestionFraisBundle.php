<?php

namespace GestionFraisBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GestionFraisBundle extends Bundle
{
}
