<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Connexion</title>

    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="Css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="Css/style.css" rel="stylesheet">

    <!-- Custom Fonts -->

	<link rel="icon" type="image/png" href="img/favicon.png" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<header class="container" id="entete">
      
    <div class="row">
        <div class=" col-sm-offset-0 col-sm-2 col-xs-12"><img src="Images/logo_gsb.png" id='logo'></div>
         <div class=" col-sm-offset-1 col-sm-8 col-xs-12"><h1 class="title" > Gestion des frais de visite </h1></div>
    </div>
      
       
      </div>
</header>
<footer class="container" >

    <div class="row">
    <div class="col-sm-10 col-sm-offset-1" id="footer">
        <div class="col-sm-8 col-sm-offset-2">
            <div class="col-sm-3" ><a>Mentions légales</a></div>
            <div class="col-sm-3" ><a>Conditions générales d'utilisations</a></div>
            <div class="col-sm-3"><a>Contact</a></div>
            <div class="col-sm-3"><a>Contact2</a></div>
        </dov>
    </div>

    </div>
</footer>
</body>